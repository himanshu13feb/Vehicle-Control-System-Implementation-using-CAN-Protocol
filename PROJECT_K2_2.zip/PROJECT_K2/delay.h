#include "types.h"
uint8_t delay_us(uint32_t value);
uint8_t delay_ms(uint32_t value);
uint8_t delay_s(uint32_t value);

