#include"types.h"

void init_adc(char ch_no);

void set_adc_pin_out(char ch_no);

void start_adc(void);
void stop_adc(void);

int read_adc(uint8_t ch_no);
float adc_map(int adc_val,float min,float max);

float fual_conversion(int x,float min,float max);

