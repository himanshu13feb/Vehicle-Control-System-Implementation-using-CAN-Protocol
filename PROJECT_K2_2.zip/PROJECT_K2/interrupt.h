#include "types.h"

void EXT0_ISR(void) __irq;
void EXT1_ISR(void) __irq;
void EXT2_ISR(void) __irq;
void EXT3_ISR(void) __irq;

void UART0_ISR(void) __irq;
void UART1_ISR(void) __irq;

void init_interrupt(uint8_t interrupt_no,uint8_t priority, void isr(void)__irq);

