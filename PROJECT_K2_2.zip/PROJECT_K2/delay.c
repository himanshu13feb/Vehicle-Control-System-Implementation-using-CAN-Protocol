#include "types.h"
#include "delay.h"

uint8_t delay_us(uint32_t value){	
	value*=12;
	while(--value);
	return 0;
}

uint8_t delay_ms(uint32_t value){
		value*=12000;
		while(value--);
		return 0;
}

uint8_t delay_s(uint32_t value){
		value*=12000000;
		while(value--);
		return 0;
}
