#include "types.h"

#define clr_lcd_cmd 0X01
void init_lcd(uint8_t slotNo,uint8_t rs,uint8_t en);

void cmdWrite(uint8_t data);
void dataWrite(uint8_t data);

void lcd_string_at_pos(uint8_t row, uint8_t col, char* string);
void lcd_string_scroll(uint8_t row, char* string, uint16_t delay);
void lcd_string(char* string);
void lcd_char(char ch);

void set_cursor(uint8_t row,uint8_t col);
void clr_lcd(void);
void clr_line(uint8_t row);

void custom_char_at_pos(char *ch,char row,char col);
void custom_char_gen(char *ch,char pos);
