#include<LPC21xx.h>
#include"types.h"
#include<stdlib.h>
#include"adc.h"
#include"delay.h"


void init_adc(char ch_no){
	ADCR=0;
	set_adc_pin_out(ch_no);
	
	ADCR|=2<<8;
	ADCR|=1<<16;
}

void set_adc_pin_out(char ch_no){
			ADCR|=1<<ch_no;
}



void start_adc()
{
	ADCR|=1<<21;
}

void stop_adc()
{
	ADCR&=~(1<<21);
}

int read_adc(uint8_t ch_no)
{                                                                                                        
		while(!(*(&ADDR)>>31)&1){delay_us(3);}
			return ((*(&ADDR)>>6)&0x3FF);
}

																		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
float adc_map(int adc_val,float min,float max)
{
	float x=(max-min)/1023;
	x=(x*adc_val)+min;                                                                                                                            
    return x;
}

/*void set_adc_pin_out(char *ch_no){
	char str[3]={0},i=0;
	while(*ch_no){
				while(*ch_no!=','&&*ch_no!=0)
				{
					str[i]=*ch_no;
					ch_no++;
					i++;
				}
				str[i]=0;
				ADCR|=1<<atoi(str);
				
				i=0;
				if(!(*ch_no)) break;
				ch_no++;
		}
}
*/




