//#include <string.h>
#include "types.h"
#include "convert.h"

char buffer[20]={0};

char* itoa(int32_t value,char digits){
	char str[20];
	char i,x,flag=0;
	if(value<0) {flag=1; value=-value;};
	for(i=0;value||(i<digits);value/=10){
		str[i++]=(value%10)+48;
	}
	if(flag) str[i++]='-';
	str[i]=0;
	
	x=strlenn(str);
	for(i=0;i<x;i++){
		buffer[i]=str[x-i-1];
	}
  buffer[i]=0;
	return buffer;
}

char* ftoa(float value,char digits){
	char str[20];
	char i,x,flag=0;
	int num;
	if(value<0) {flag=1; value=-value;}
	num=(int)(value*1000);
	
	for(i=0;num||(i<(digits+3));num/=10){
		if(i==3){
			str[i++]='.';
			num*=10;
			continue;
		}
		str[i++]=(num%10)+48;
	}
	
	if(flag) str[i++]='-';
	str[i]=0;
	
	x=strlenn(str);
	for(i=0;i<x;i++){
		buffer[i]=str[x-1-i];
	}
	buffer[i]=0;
	return buffer;
}

int strlenn(char*string){
	uint32_t cnt=0;
	while(*string){
		cnt++;
		string++;
	}
	return cnt;
}

void num_convert(unsigned int num,char sel){
	int i=0,temp,x;
	char str[16];
	while(!(num<sel))
	{
		temp=num;
		num=num/sel;
		x=temp-(num*sel);
		if(x<=9)
			str[i++]=x+48;
		else
			str[i++]=x+55;
	}
		x=num;
		if(x<=9)
			str[i++]=x+48;
		else
			str[i++]=x+55;
		str[i]=0;
		x=strlenn(str);
		for(i=0;i<x;i++)
			buffer[i]=str[x-i-1];
		buffer[i]=0;
}

 char* hex(unsigned int num)
{
	num_convert(num,16);
	return buffer;
}

 char* oct(unsigned int num)
{
	num_convert(num,8);
	return buffer;
}

 char* bin(unsigned int num)
{
	num_convert(num,2);
	return buffer;
}



