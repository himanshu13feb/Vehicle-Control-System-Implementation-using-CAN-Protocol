#include"lcd.h"
#include"adc.h"
#include"delay.h"
#include"convert.h"

#define MIN_LEVEL 80
#define MAX_LEVEL 680

extern int fuel_level;
extern int eng_temp;
extern char left_sign;
extern char right_sign;
char glow=0;
char cnt=0;
void side_indicator(void);

void start_code()
{
	char fuel_symbol[]={0xff,0x0a,0x0a,0x0e,0x0e,0xff,0xff};
	char fuel_mark[]={0xff,0xff,0xff,0xff,0xff,0xff,0xff};
	char right[]={0x18,0x1c,0x1e,0x1f,0x1e,0x1c,0x18};
	char left[]={0x03,0x07,0x0f,0x1f,0x0f,0x07,0x03};
	char temp[]={0x04,0x0a,0x0a,0x0e,0x1f,0x1f,0x0e};
	char dot[]={0x18,0x18,0x00,0x07,0x08,0x08,0x07};
	
	custom_char_gen(fuel_symbol,0);
	custom_char_gen(fuel_mark,1);
	custom_char_gen(right,2);
	custom_char_gen(left,3);
	custom_char_gen(temp,4);
	custom_char_gen(dot,5);
	
	custom_char_at_pos(fuel_symbol,1,12);
	
	start_adc();
}

void print_data_on_lcd()
{
	int i;	
	
	clr_lcd();
	set_cursor(1,1);	
	dataWrite(4);
	lcd_string_at_pos(1,2,itoa(eng_temp,2));
	dataWrite(5);
	//lcd_char('C');
	set_cursor(1,12);
	dataWrite(0);
	lcd_string_at_pos(1,13,itoa(fuel_level,2)); 
	lcd_char('%');
	
	side_indicator();
	
	lcd_string_at_pos(2,9,"E");
	lcd_string_at_pos(2,15,"F");
	
	
	for(i=0;i<((float)fuel_level/20)&&i<=4;i++)
	{
			set_cursor(2,i+10);	
			dataWrite(1);
	}
	delay_ms(100);
}

void fuel_level_measurement(void)
{
	int i;
	for(i=1;i<=10;i++)
	{
		fuel_level+=read_adc(1);		
	}
	fuel_level/=10;
	fuel_level=(int)fual_conversion(fuel_level,MIN_LEVEL,MAX_LEVEL);
	if(fuel_level<0) fuel_level=0;
	if(fuel_level>99) fuel_level=99;
}

float fual_conversion(int x,float min,float max)
{
	float z=100*((x-min)/(max-min));
	return z;
}

void engine_temp_measuremnt()
{
	int i;float temp;
	for(i=1;i<=10;i++)
	{
		eng_temp+=read_adc(1);		
	}
	eng_temp/=10;
	temp=adc_map(eng_temp,0,3.3);
	eng_temp=(int)(temp*100);

}

void side_indicator()
{
	if(left_sign==0 && right_sign==0)
	{
	set_cursor(2,2);
	dataWrite(3);
	set_cursor(2,4);
	dataWrite(2);
	}
	else if(left_sign==1)
	{
		if(glow)
		{
			set_cursor(2,2);
			dataWrite(3);
		}
		set_cursor(2,4);
		dataWrite(2);
		cnt++;
		if(cnt==5) 
		{	
		glow=!glow;
		cnt=0;
		}
	}
	
	else if(right_sign==1)
	{
		if(glow)
		{
			set_cursor(2,4);
			dataWrite(2);
		}
		set_cursor(2,2);
		dataWrite(3);
		cnt++;
		if(cnt==5) 
		{	
		glow=!glow;
		cnt=0;
		}
	}	
}

