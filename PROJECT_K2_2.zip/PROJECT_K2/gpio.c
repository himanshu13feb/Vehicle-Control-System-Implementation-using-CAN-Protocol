//************ gpio.c ****************//

/*  port0 pin 0  to 7   ==> slotNO 0
	port0 pin 8  to 15  ==> slotNO 1
	port0 pin 15 to 23  ==> slotNO 2
	port0 pin 24 to 31  ==> slotNO 3

	port_0Write(portNo,value)   portNo should be between o to 3
								 value should be between 0 to 255
*/

//***************************************************************************
 
 /* 
	port1 pin 15 to 23  ==> slotNO 0
	port1 pin 24 to 31  ==> slotNO 1

	port_1Write(portNo,value)   slotNO should be between o to 3
								 value should be between 0 to 255
*/
//***************************************************************************

#include "macro.h"
#include "types.h"
#include "gpio.h"
#include<LPC21xx.h>

//////////////////////////////////////////////////////////////
void p0_BitWrite(uint8_t pinNO,uint8_t i){
	WRBIT(IOPIN0,pinNO,i);
}

void p1_BitWrite(uint8_t pinNO,uint8_t i){
	WRBIT(IOPIN1,pinNO,i);
}
//*************************************************************
void p0_ByteWrite(uint8_t slotNO,uint16_t i){
	WRBYTE(IOPIN0,slotNO*8,i);
}

void p1_ByteWrite(uint8_t slotNO,uint16_t i){
	WRBYTE(IOPIN1,(slotNO+2)*8,i);
}
//**************************************************************
void p0_NibWrite(uint8_t slotNO,uint8_t i){
	WRNIB(IOPIN0,slotNO*4,i);
}

void p1_NibWrite(uint8_t slotNO,uint8_t i){
	WRNIB(IOPIN1,(slotNO+4)*4,i);
}
//////////////////////////////////////////////////////////////////
uint8_t p0_portRead(uint8_t slotNO){
	uint8_t x=RDBYTE(IOPIN0,slotNO*8);
	return x;
}

uint8_t p1_portRead(uint8_t slotNO){
	uint8_t x=RDBYTE(IOPIN1,(slotNO+2)*8);
	return x;
}
//****************************************************************
uint8_t p0_pinRead(uint8_t pinNO){
   uint8_t x=RDBIT(IOPIN0,pinNO);
   return x;
} 
uint8_t p1_pinRead(uint8_t pinNO){
	uint8_t x=RDBIT(IOPIN1,pinNO);
	return x;
}
///////////////////////////////////////////////////////////////////

void p0_pinMode(uint8_t pinNO,uint8_t i){
	WRBIT(IODIR0,pinNO,i);
}
void p1_pinMode(uint8_t pinNO,uint8_t i){
	WRBIT(IODIR1,pinNO,i);
}

void p0_portMode(uint8_t slotNo,uint8_t i){
	WRBYTE(IODIR0,slotNo*8,i);	
}
void p1_portMode(uint8_t slotNo,uint8_t i){
	 WRBYTE(IODIR1,(slotNo+2)*8,i);
}

///////////////////////////////////////////////////////////////////

void p0_pinSelect(uint8_t pinNo,uint8_t selection){
	if(pinNo<16)  PINSEL0|= selection<<(pinNo*2);
	else PINSEL1|= selection<<((pinNo-16)*2);
}

void p1_pinSelect(uint8_t pinNo,uint8_t selection){
	PINSEL1|= selection<<((pinNo-16)*2);
}



