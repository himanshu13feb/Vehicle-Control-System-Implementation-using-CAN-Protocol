#include "types.h"

void p0_BitWrite(uint8_t pinNO,uint8_t i);
void p1_BitWrite(uint8_t pinNO,uint8_t i);

void p0_ByteWrite(uint8_t slotNO,uint16_t i);
void p1_ByteWrite(uint8_t slotNO,uint16_t i);

void p0_NibWrite(uint8_t slotNO,uint8_t i);
void p1_NibWrite(uint8_t slotNO,uint8_t i);

uint8_t p0_portRead(uint8_t slotNO); 
uint8_t p1_portRead(uint8_t slotNO);

uint8_t p0_pinRead(uint8_t pinNO); 
uint8_t p1_pinRead(uint8_t pinNO);

void p0_pinMode(uint8_t pinNO,uint8_t i);
void p1_pinMode(uint8_t pinNO,uint8_t i);

void p0_portMode(uint8_t slotNo,uint8_t i);
void p1_portMode(uint8_t slotNo,uint8_t i);

void p0_pinSelect(uint8_t pinNo,uint8_t selection);
void p1_pinSelect(uint8_t pinNo,uint8_t selection);

