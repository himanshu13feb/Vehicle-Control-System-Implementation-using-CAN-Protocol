#include "types.h"
char* itoa(int32_t value,char digits);
char* ftoa(float value,char digits);
int strlenn(char*string);

