#include "types.h"
#include "delay.h"
#include "lcd.h"
#include "interrupt.h"
#include<LPC214X.h>



void init_interrupt(uint8_t interrupt_no,uint8_t priority,void isr(void)__irq){
  VICIntEnable|= (1<<interrupt_no);
  *(&VICVectCntl0+priority) = (1<<5)|interrupt_no;
  *(&VICVectAddr0+priority) = (unsigned long)isr;		
}

