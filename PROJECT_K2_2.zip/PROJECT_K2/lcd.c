#include "types.h"
#include "gpio.h"
#include "delay.h"
#include "lcd.h"
#include <string.h>

uint8_t lcd_slotNo;
uint8_t rs;
uint8_t en;


void init_lcd(uint8_t slotNo,uint8_t lcd_rs,uint8_t lcd_en){
	 
	 lcd_slotNo=slotNo;
	 rs=lcd_rs;
	 en=lcd_en;

	 p0_portMode(lcd_slotNo,0xFF);
	 p0_pinMode(rs,1);
	 p0_pinMode(en,1);
	 
	delay_ms(50);
	cmdWrite(0x30);
	delay_ms(5);
	cmdWrite(0x30);
	delay_ms(1);
	cmdWrite(0x30);
	
	cmdWrite(0x01); //clear display
	delay_ms(2);
	cmdWrite(0x38); //function set  DL=1:8-BIT MODE  N=0:1-LINE DISPLAY F=0: 5X8 DOT  (0 0 1 DL N F 0 0)
	cmdWrite(0x0C);
	cmdWrite(0x06);
}

void cmdWrite(uint8_t data){
	p0_BitWrite(rs,0);
	p0_ByteWrite(lcd_slotNo,data);
	p0_BitWrite(en,1);
	delay_us(10);
	p0_BitWrite(en,0);
	delay_us(40);
}

void dataWrite(uint8_t data){
	p0_BitWrite(rs,1);
	p0_ByteWrite(lcd_slotNo,data);
	p0_BitWrite(en,1);
	delay_us(10);
	p0_BitWrite(en,0);
	delay_us(40);	
}

void lcd_string(char* string){
	while(*string){
		dataWrite(*(string++));
	}
}

void lcd_char(char ch){
		dataWrite(ch);
	}


void lcd_string_at_pos(uint8_t row, uint8_t col, char* string){
	set_cursor(row,col);
	lcd_string(string);
}

void clr_lcd(){
	cmdWrite(clr_lcd_cmd);
	delay_ms(2);
}

void set_cursor(uint8_t row,uint8_t col){
	uint8_t i;
	if(row==2) cmdWrite(0xC0);
	else cmdWrite(0x80);
	for(i=0;i<col;i++){			
		cmdWrite(0x14);
	}
}

void clr_line(uint8_t row){	
   uint8_t i;
   set_cursor(row,0);
   for(i=16;i>0;i--){			
			dataWrite(32);
		}
}

void lcd_string_scroll(uint8_t row, char* string, uint16_t delay){
	int8_t i,j,z,m=0,k=(strlen((const char*)string))-1;
	
	while(1){
		clr_line(row);			    /* clear perticuler row*/
		set_cursor(row,0);
		
		for(i=0;i<15-m;i++){		/* print spaces*/	
			dataWrite(32);
		}
		if(m<k) z=m; else z=k;
		
		for(j=0;j<=z;j++){			/* print character*/
			dataWrite(string[j]);
		}
		delay_ms(delay);
		m++;
		if(m==16) break;
	}
	
	 for(i=1;i<=k;i++){		
		clr_line(row);			    /* clear perticuler row*/
		set_cursor(row,0);
		if((k-i)>15) z=16; else z=k-i;
		for(j=i;j<=z+i;j++){			/* print character*/
			dataWrite(string[j]);
		}
		delay_ms(delay);
	}
}

void custom_char_gen(char *ch,char pos)
{
	int i;
	cmdWrite(0x40+(pos*8));
	for(i=0;i<7;i++)
		dataWrite(ch[i]);
}

void custom_char_at_pos(char *ch,char row,char col)
{
	
	custom_char_gen(ch,0);
	set_cursor(row,col);
	dataWrite(0);
}















