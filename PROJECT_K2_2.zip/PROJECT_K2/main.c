#include<LPC21xx.h>
#include "types.h"
#include "adc.h"
#include "delay.h"
#include "lcd.h"
#include "gpio.h"
#include "convert.h"
#include "interrupt.h"



int fuel_level;
int eng_temp=39;
char left_sign;
char right_sign;
	
void start_code(void);
void update_data(void);
void fuel_level_measurement(void);
void print_data_on_lcd(void);
void engine_temp_measuremnt(void);

int main(){

	
	p0_pinSelect(27,0x01);
	p0_pinSelect(28,0x01);
	
	init_interrupt(14,14,EXT0_ISR);
	p0_pinSelect(16,0x01);
	EXTMODE|=1<<0;
	EXTPOLAR|=0<<0;	
	
	init_interrupt(17,15,EXT3_ISR);
	p0_pinSelect(20,0x03);
	EXTMODE|=1<<3;
	EXTPOLAR|=0<<3;
	
	
	
	init_adc(1);
	init_lcd(1,6,7);
	start_code();
	
	while(1){
		
		//fuel_level_measurement();
		engine_temp_measuremnt();
		print_data_on_lcd();
	}
}


void EXT0_ISR(void) __irq
{
	int temp=EXTINT;
 	if(left_sign==1)
	{
		left_sign=0;
	}
	else
	{
		right_sign=0;
		left_sign=1;
	}
	EXTINT=temp;
	VICVectAddr=0;
}


void EXT3_ISR(void) __irq
{
int temp=EXTINT;
 	if(right_sign==1)
	{
		right_sign=0;
	}
	else
	{
		right_sign=1;
		left_sign=0;
	}
EXTINT=temp;
VICVectAddr=0;
}


